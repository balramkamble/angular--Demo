import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { book } from './book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {


  private booklist: book[] = [
    new book(101, "HTML & CSS", "The Definitive Guide to HTML & CSS--Fully UpdatedWritten by a Web development expert, the fifth edition of this trusted resource has been thoroughly revised and reorganized to address HTML5, the revolutionary new Web standard.", 500),
    new book(102, "Java", "A step-by-step guide by the famous computing author Herbert Schildt, Java: The Complete Reference, Seventh Edition is an introductory book to Java. Whether a person is a rookie or a pro programmer, this book is for everyone. ", 300),
  ]
  constructor() { }

  /*updated booklist */
  private updatebooklist = new Subject<book[]>();
  getUpdatebooklist() {
    return this.updatebooklist.asObservable();
  }

  getBookslist() {
    return [...this.booklist];
  }
  addBookslist(bid: number, btitle: string, bdesc: string, bprice: number) {
    let blist = new book(bid, btitle, bdesc, bprice);
    this.booklist.push(blist);
    this.updatebooklist.next([...this.booklist])
  }





}

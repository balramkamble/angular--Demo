import { TestBed } from '@angular/core/testing';

import { SerEmpService } from './ser-emp.service';

describe('SerEmpService', () => {
  let service: SerEmpService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SerEmpService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  loginsURL: string = 'http://localhost:3000/logins';
  loginsUpdated = new Subject<boolean>();

  uLGdata: [] = [];
  loginList: any;



  constructor(private http: HttpClient) {
    this.getLoginlist().subscribe((ulist: any) => {
      return this.uLGdata = ulist;
    })
  }

  getLoginlist(): Observable<any> {
    return this.http.get<any>(this.loginsURL);
  }

  onLogin(email: string, password: string) {
    this.loginList = this.uLGdata.find((ulist: any) => {
      return email == ulist.email && password == ulist.password;
    })

    if (email == this.loginList.email && password == this.loginList.password) {
      this.loginsUpdated.next(true);
      return true
    } else {
      return false;
    }
  }


}

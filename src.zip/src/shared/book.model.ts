export class book {
    bid: number;
    btitle: string;
    bdesc: string;
    bprice: number;
    constructor(bid: number, btitle: string, bdesc: string, bprice: number) {
        this.bid = bid;
        this.btitle = btitle
        this.bdesc = bdesc;
        this.bprice = bprice;
    }
}
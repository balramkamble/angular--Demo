import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { employee } from './emp.model';

@Injectable({
  providedIn: 'root'
})
export class SerEmpService {


  allEmp: employee[] = [
    new employee(1, "Ram", "Male", "Manager", 150000, ["Angular", "Fullstack"]),
  ]
  constructor() { }

  /* updated emplist */
  private updateemplist = new Subject<employee[]>();
  getUpdatedEmplist() {
    return this.updateemplist.asObservable();
  }

  getEmplist() {
    return [...this.allEmp]
  }
  addEmplist(eid: number, ename: string, egender: string, designation: string, esalary: number, eskills: string[]) {
    let nemplist = new employee(eid, ename, egender, designation, esalary, eskills);
    this.allEmp.push(nemplist);
    this.updateemplist.next([...this.allEmp]);
  }



}

import { TestBed } from '@angular/core/testing';

import { MempService } from './memp.service';

describe('MempService', () => {
  let service: MempService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MempService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { employee } from './emp.model';

@Injectable({
  providedIn: 'root'
})
export class MempService {

  EmpURL: string = "http://localhost:3000/employee";
  constructor(private _http: HttpClient) { }



  getAll(){
    return this._http.get<employee[]>(this.EmpURL);
  }
  getById(id:number){
    return this._http.get<employee>(`${this.EmpURL}/${id}`)
  }
  create(params:any){
    return this._http.post<employee[]>(this.EmpURL, params);
  }
  update(id:number, params:any){
    return this._http.put<employee[]>(`${this.EmpURL}/${id}`, params);
  }
  delete(id:number){
    return this._http.delete<employee[]>(`${this.EmpURL}/${id}`);
  }

   
}

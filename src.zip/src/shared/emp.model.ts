export class employee {
    public eid:number;
    public ename:string;
    public egender:string;
    public designation:string;
    public esalary:number;
    public eskills:string[];

    constructor( eid:number, ename:string, egender:string, designation:string, esalary:number, eskills:string[]){
       this.eid = eid;
        this.ename = ename;
        this.egender = egender;
        this.designation = designation;
        this.esalary = esalary;
        this.eskills = eskills;
    }
}

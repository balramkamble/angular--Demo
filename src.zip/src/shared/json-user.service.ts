import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { users } from './users.model';


@Injectable({
  providedIn: 'root'
})
export class JsonUserService {

  usersURL: string = 'http://localhost:3000/users';
  usersUpdated = new Subject();

  constructor(private http: HttpClient) { }

  ngOnInit(): void {

  }

  /* get all user */
  getAllusers(): Observable<users[]> {
    return this.http.get<users[]>(this.usersURL);
  }
  /* add user in list */
  addUserData(udata: any): Observable<users> {
    return this.http.post<users>(this.usersURL, udata);
  }
  /* delete user using by id */
  deleteUserbyId(id: number): Observable<users> {
    return this.http.delete<users>(`${this.usersURL}/${id}`);
  }
  /* get user details using by id */
  getUserById(id: any): Observable<users> {
    return this.http.get<users>(`${this.usersURL}/${id}`);
  }
  /* edit user using by id  */
  editUserById(id: any, editUser: any): Observable<users> {
    return this.http.put<users>(`${this.usersURL}/${id}`, editUser)
  }
}

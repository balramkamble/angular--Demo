import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { employee } from './emp.model';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiempService implements OnInit {

  EmpURL: string = "http://localhost:3000/employee";

  emplistUpdated = new Subject<boolean>();

  constructor(private _http: HttpClient) { }

  ngOnInit(): void {

  }

  getapiEmplist(): Observable<employee[]> {
    return this._http.get<employee[]>(this.EmpURL);
  }
  addapiEmplist(eid: number, ename: string, egender: string, designation: string, esalary: number, eskills: string[]): Observable<employee> {
    let nwEmplist = new employee(eid, ename, egender, designation, esalary, eskills)
    return this._http.post<employee>(this.EmpURL, nwEmplist);
  }

  deleteapiEmplist(id:number):Observable<employee>{
   return  this._http.delete<employee>(`${this.EmpURL}/${id}`);
    
  }

}

import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-forms',
  templateUrl: './reactive-forms.component.html',
  styleUrls: ['./reactive-forms.component.scss']
})
export class ReactiveFormsComponent implements OnInit {
  isDisplay: boolean = true;
  userInfo = {
    name: '',
    username: '',
    email: '',
    street: '',
    suite: '',
    city: '',
    zipcode: '',
    phone: '',
    website: '',
    company: '',
  }
  userInfoForm: FormGroup;

  restrictedNames: string[] = ['balram', 'ram'];
  constructor(private http:HttpClient) { }


  ngOnInit(): void {

    this.userInfoForm = new FormGroup({
      userData: new FormGroup({
        name: new FormControl('', [Validators.required, this.addRestrictedNames.bind(this)]),
        username: new FormControl('', Validators.required),
      }),

      email: new FormControl('', [Validators.required, Validators.email]),
      street: new FormControl('', Validators.required),
      suite: new FormControl('', Validators.required),
      city: new FormControl('', Validators.required),
      zipcode: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(6)]),
      phone: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
      website: new FormControl('', Validators.required),
      company: new FormControl('', Validators.required),
    })

    /* value changes */
    this.userInfoForm.valueChanges.subscribe((val) => {
      console.log(val)
    });
    /* status changes */
    this.userInfoForm.statusChanges.subscribe((val) => {
      console.log(val)
    });


  }

  addUserListInfo() {
    const USData = this.userInfoForm.value;
    this.http.post('http://users-5ff33-default-rtdb.firebaseio.com/users.json', USData).subscribe((rdata)=>{
      console.log(rdata)
    })

    console.log(this.userInfoForm.value);
    this.isDisplay = false;
    this.userInfo = {
      name: this.userInfoForm.value.name,
      username: this.userInfoForm.value.username,
      email: this.userInfoForm.value.email,
      street: this.userInfoForm.value.street,
      suite: this.userInfoForm.value.suite,
      city: this.userInfoForm.value.city,
      zipcode: this.userInfoForm.value.zipcode,
      phone: this.userInfoForm.value.phone,
      website: this.userInfoForm.value.website,
      company: this.userInfoForm.value.company,
    }
  }
  addRestrictedNames(userForm: FormControl) {
    if (this.restrictedNames.includes(userForm.value)) {
      return { nmRestricted: true };
    }
    return null;
  }


  /* set Value patch value, value changes, status changes */
  setValues() {
    this.userInfoForm.setValue({
      userData: {
        name: "Aradhya",
        username: "AradhyaKamble",
      },

      email: "aradhyakamble@gmail.com",
      street: "gondhale nagar",
      suite: "hadapsar",
      city: "pune",
      zipcode: "411028",
      phone: "9999999999",
      website: "abc.com",
      company: "abc",
    })
  }
  patchValues() {
    this.userInfoForm.patchValue({
      email: 'bk@gmail.com',
      phone: '9766909796'
    })
  }

}

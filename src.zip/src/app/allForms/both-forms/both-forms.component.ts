import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-both-forms',
  templateUrl: './both-forms.component.html',
  styleUrls: ['./both-forms.component.scss']
})
export class BothFormsComponent implements OnInit {

  @ViewChild('tuserForm') userInfoForm: NgForm;
  constructor() { }



  addUserInfo(tuserForm: NgForm) {
    console.log(tuserForm.value)
  }
  onSetValues() {
    this.userInfoForm.setValue({
      fname: "Aradhya Kamble",
      email: "ak@gmail.com ",
      education: "master",
      sports: true,
      movies: false,
      gender: "female"
    })
  }

  /*Reactive form */
  RecUserForm: FormGroup;
  ngOnInit(): void {
    this.RecUserForm = new FormGroup({
      fname: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required]),
      education: new FormControl('', [Validators.required]),
      rsports: new FormControl(''),
      rmovies: new FormControl(''),
      rgender: new FormControl(''),

    })
  }
  addRecUserForm() {
    console.log(this.RecUserForm.value)
  }
  addRecSetValues() {
    this.RecUserForm.setValue({
      fname: "Baliram Kamble",
      email: "bk@gmail.com ",
      education: "master",
      rsports: true,
      rmovies: true,
      rgender: "male"
    })

  }
  addRecPatchValues() {
    this.RecUserForm.setValue({
      fname: "Baliram Kamble",
      email: "balramk@gmail.com ",
      education: "master",
      rsports: true,
      rmovies: false,
      rgender: "male"
    })
  }

}

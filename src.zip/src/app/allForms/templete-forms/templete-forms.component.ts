import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-templete-forms',
  templateUrl: './templete-forms.component.html',
  styleUrls: ['./templete-forms.component.scss']
})
export class TempleteFormsComponent implements OnInit {

  @ViewChild('userInfo') userForm: NgForm;
  submitted: boolean = false;
  personalData = {
    name: '',
    username: '',
    email: '',
    street: '',
    suite: '',
    city: '',
    zipcode: '',
    phone: '',
    website: '',
    company: '',
  }

  constructor() { }

  ngOnInit(): void {
  }

  addUserListInfo() {
    console.log(this.userForm);
    this.submitted = true;

    this.personalData.name = this.userForm.value.perData.name;
    this.personalData.username = this.userForm.value.perData.username;
    this.personalData.email = this.userForm.value.email;
    this.personalData.street = this.userForm.value.street;

    this.personalData.suite = this.userForm.value.suite;
    this.personalData.city = this.userForm.value.city;

    this.personalData.zipcode = this.userForm.value.zipcode;
    this.personalData.phone = this.userForm.value.phone;

    this.personalData.website = this.userForm.value.website;
    this.personalData.company = this.userForm.value.company;

    this.userForm.reset();

  }
  fillValues() {
    this.userForm.form.setValue({
      perData: {
        name: 'baliram',
        username: 'baliram kamble'
      },
      email: 'balram.kamble@gmail.com',
      street: 'Gondhale Nagar',
      suite: 'Hadapsar',
      city: 'Pune',
      zipcode: '411028',
      phone: '9766909796',
      website: 'www.abk.com',
      company: 'ABK'
    })
  }

  /*
  add some part of element value so use patchValue 
  and add whole form value so use setValue
    fillValues() {
    this.userForm.form.patchValue({
      perData: {
        name: 'baliram',
        username: 'baliram kamble'
      },
      email: 'balram.kamble@gmail.com',
      street: 'Gondhale Nagar',
      suite: 'Hadapsar',
      city: 'Pune',
      zipcode: '411028',
    })
  }
  */

}

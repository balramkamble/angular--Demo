import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { JsonUserService } from 'src/shared/json-user.service';

@Component({
  selector: 'app-usersedit',
  templateUrl: './usersedit.component.html',
  styleUrls: ['./usersedit.component.scss']
})
export class UserseditComponent implements OnInit {

  uid: any;
  constructor(private _userSer: JsonUserService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {

    /* get user id by using route */
    this.route.params.subscribe((params: Params) => {
      console.log(params['id']);
      this.uid = +params['id'];

      /*get users details using id */
      this._userSer.getUserById(this.uid).subscribe((getUsers) => {
        console.log(getUsers);

        setTimeout(() => {
          this.editUsersForm.setValue({
            name: getUsers.name, username: getUsers.username, email: getUsers.email,
            street: getUsers.street, suite: getUsers.suite, city: getUsers.city, zipcode: getUsers.zipcode,
            phone: getUsers.phone, website: getUsers.website, company: getUsers.company
          });
        }, 1000)

      })

    });




  }


  editUsersForm = new FormGroup({
    // id: new FormControl(),
    name: new FormControl('', [Validators.required]),
    username: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    //address
    street: new FormControl('', [Validators.required]),
    suite: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    zipcode: new FormControl('', [Validators.required]),

    phone: new FormControl('', [Validators.required]),
    website: new FormControl('', [Validators.required]),
    company: new FormControl('', [Validators.required]),
  })

  onEditUsers() {
    console.log(this.editUsersForm.value);
    this._userSer.editUserById(this.uid, this.editUsersForm.value).subscribe((updatedata) => {
      this._userSer.usersUpdated.next(true);
    });
    this.editUsersForm.reset();
  }

}

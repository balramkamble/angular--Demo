import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { JsonUserService } from 'src/shared/json-user.service';

@Component({
  selector: 'app-userscreate',
  templateUrl: './userscreate.component.html',
  styleUrls: ['./userscreate.component.scss']
})
export class UserscreateComponent implements OnInit {

  constructor(private _userSer: JsonUserService) { }

  addUsersForm = new FormGroup({
    // id: new FormControl(),
    name: new FormControl('', [Validators.required]),
    username: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    //address
    street: new FormControl('', [Validators.required]),
    suite: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    zipcode: new FormControl('', [Validators.required]),

    phone: new FormControl('', [Validators.required]),
    website: new FormControl('', [Validators.required]),
    company: new FormControl('', [Validators.required]),
  })
  onAddUsers() {
    this._userSer.addUserData(this.addUsersForm.value).subscribe((result) => {
      this._userSer.usersUpdated.next(true);
    })
    this.addUsersForm.reset();
  }

  ngOnInit(): void {
  }

}

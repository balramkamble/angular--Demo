import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { JsonUserService } from 'src/shared/json-user.service';
import { users } from 'src/shared/users.model';

@Component({
  selector: 'app-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.scss']
})
export class ViewuserComponent implements OnInit {

  uid: any;
  userDetails: any;
  constructor(private route: ActivatedRoute, private router: Router, private _userService: JsonUserService) { }

  ngOnInit(): void {

    /* get id using params */
    this.route.params.subscribe((params: Params) => {
      console.log(params['id']);
      //this.uid = + params['id'];

      this._userService.getUserById(params['id']).subscribe((userData) => {
        console.log(userData);
        this.userDetails = userData;
      })

    })



  }

}

import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { JsonUserService } from 'src/shared/json-user.service';

@Component({
  selector: 'app-userslistitem',
  templateUrl: './userslistitem.component.html',
  styleUrls: ['./userslistitem.component.scss']
})
export class UserslistitemComponent implements OnInit {


  @Input() userlistitem: any;
  constructor(private _userSer: JsonUserService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {

  }

  deleteUsersitem() {
    if (confirm("are you delete")) {
      this._userSer.deleteUserbyId(this.userlistitem.id).subscribe((deleteditem) => {
        this._userSer.usersUpdated.next(true)
      })
    }
  }

  viewUserDetails() {
    this.router.navigate(['view', this.userlistitem.id], { relativeTo: this.route })
  }
  editUsersItem() {
    this.router.navigate(['edit', this.userlistitem.id], { relativeTo: this.route })
  }

}

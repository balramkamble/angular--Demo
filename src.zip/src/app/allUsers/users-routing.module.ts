import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/shared/auth.guard';
import { UsersComponent } from './users/users.component';
import { UserscreateComponent } from './userscreate/userscreate.component';
import { UserseditComponent } from './usersedit/usersedit.component';
import { ViewuserComponent } from './viewuser/viewuser.component';


const routes: Routes = [
  {
    path: 'users', component: UsersComponent, data: { pageTitle: 'userslist' },
    children: [
      { path: 'add', component: UserscreateComponent },
      { path: 'view/:id', component: ViewuserComponent },
      { path: 'edit/:id', component: UserseditComponent }
    ],
    canActivate: [AuthGuard]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsersRoutingModule } from './users-routing.module';
import { UsersComponent } from './users/users.component';
import { UserscreateComponent } from './userscreate/userscreate.component';
import { UserslistComponent } from './userslist/userslist.component';
import { UserslistitemComponent } from './userslistitem/userslistitem.component';
import { ViewuserComponent } from './viewuser/viewuser.component';
import { UserseditComponent } from './usersedit/usersedit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AllCommonModule } from '../common/all-common.module';
//import { ShortStringPipe } from '../common/appPipes/short-string.pipe';


@NgModule({
  declarations: [
    UsersComponent,
    UserslistComponent,
    UserslistitemComponent,
    UserscreateComponent,
    UserseditComponent,
    ViewuserComponent,
    //ShortStringPipe,
  ],
  imports: [
    CommonModule,
    UsersRoutingModule,
   // FormsModule,
    //ReactiveFormsModule,
    AllCommonModule,
    
  ]
})
export class UsersModule { }

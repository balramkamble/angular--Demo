import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { JsonUserService } from 'src/shared/json-user.service';
import { users } from 'src/shared/users.model';

@Component({
  selector: 'app-userslist',
  templateUrl: './userslist.component.html',
  styleUrls: ['./userslist.component.scss']
})
export class UserslistComponent implements OnInit {

  userslist: users[] = [];
  userSubscription: Subscription;

  constructor(private _userSer: JsonUserService) { }

  ngOnInit(): void {

    this.userSubscription = this._userSer.getAllusers().subscribe((ulist: any) => {
      this.userslist = ulist;
      console.log(ulist);
    })

    this._userSer.usersUpdated.subscribe((nwdata:boolean)=>{
      if(nwdata){
        this._userSer.getAllusers().subscribe((updateduserlist:users[])=>{
          this.userslist = updateduserlist;
        })
      }
    })

  }

  ngOnDestroy() {
    this.userSubscription.unsubscribe();
  }

}

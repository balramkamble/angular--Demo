import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appMyHighlight]'
})
export class MyHighlightDirective {

  constructor(private element:ElementRef,) {
   // (this.element.nativeElement as HTMLElement).style.backgroundColor = "red";
   this.element.nativeElement.style.backgroundColor = "yellow";
   }

   

}

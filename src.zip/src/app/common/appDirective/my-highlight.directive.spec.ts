import { MyHighlightDirective } from './my-highlight.directive';

describe('MyHighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new MyHighlightDirective();
    expect(directive).toBeTruthy();
  });
});

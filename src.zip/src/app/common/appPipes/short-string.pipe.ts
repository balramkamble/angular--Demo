import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'shortString'
})
export class ShortStringPipe implements PipeTransform {
  transform(value: string): string {

    if (value.length > 10) {
      return value.substring(0, 10) + "..."
    }
    return value
  }
}
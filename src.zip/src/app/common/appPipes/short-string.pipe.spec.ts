import { ShortStringPipe } from './short-string.pipe';

describe('ShortStringPipe', () => {
  it('create an instance', () => {
    const pipe = new ShortStringPipe();
    expect(pipe).toBeTruthy();
  });
});

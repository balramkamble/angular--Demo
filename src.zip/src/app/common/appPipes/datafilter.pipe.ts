import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'datafilter'
})
export class DatafilterPipe implements PipeTransform {

  transform(value: any, filterString: string): any {
    if(value.length === 0 || filterString === ''){
      return value;
    }
    const users = [];
    for(const user of value){
      if(user['name'] === filterString){
        users.push(user);
      }
    }
    return users
  }

}

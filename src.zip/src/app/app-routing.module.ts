import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './allUsers/about/about.component';
import { ContactComponent } from './allUsers/contact/contact.component';
import { HomeComponent } from './allUsers/home/home.component';
import { UsersComponent } from './allUsers/users/users.component';
import { UserscreateComponent } from './allUsers/userscreate/userscreate.component';
import { UserseditComponent } from './allUsers/usersedit/usersedit.component';
import { ViewuserComponent } from './allUsers/viewuser/viewuser.component';


const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component:  HomeComponent},
  { path: 'about', component:  AboutComponent},
  {
    path: 'users', component: UsersComponent,
    children:[
      {path: 'add', component: UserscreateComponent},
      {path: 'view/:id', component: ViewuserComponent},
      {path: 'edit/:id', component: UserseditComponent}
    ]
  },
  { path: 'contact', component:  ContactComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/shared/auth.guard';
import { AboutComponent } from './about/about.component';
import { BothFormsComponent } from './allForms/both-forms/both-forms.component';
import { ReactiveFormsComponent } from './allForms/reactive-forms/reactive-forms.component';
import { TempleteFormsComponent } from './allForms/templete-forms/templete-forms.component';

import { AuthComponent } from './app_credential/auth/auth.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';



const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'auth', component: AuthComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'tforms', component: TempleteFormsComponent, canActivate: [AuthGuard] },
  { path: 'rforms', component: ReactiveFormsComponent, canActivate: [AuthGuard] },
  { path: 'aforms', component: BothFormsComponent, canActivate: [AuthGuard] },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule} from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { AboutComponent } from './about/about.component';
import { ReactiveFormsComponent } from './allForms/reactive-forms/reactive-forms.component';
import { TempleteFormsComponent } from './allForms/templete-forms/templete-forms.component';



import { MyHighlightDirective } from './common/appDirective/my-highlight.directive';
import { DatafilterPipe } from './common/appPipes/datafilter.pipe';

import { ContactComponent } from './contact/contact.component';
import { UsersModule } from './allUsers/users.module';
import { AllCommonModule } from './common/all-common.module';
import { BothFormsComponent } from './allForms/both-forms/both-forms.component';
import { AuthComponent } from './app_credential/auth/auth.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AboutComponent,
    ContactComponent,
    
    DatafilterPipe,   
    MyHighlightDirective,
    
    TempleteFormsComponent,
    ReactiveFormsComponent,
    BothFormsComponent,
    AuthComponent,   
  ],
  imports: [
    BrowserModule,
    UsersModule,
    AllCommonModule,
    AppRoutingModule,
   // FormsModule,
   // ReactiveFormsModule,
    HttpClientModule  
    
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor(){
    console.log('app module')
  }
}

import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule} from '@angular/common/http';
import { HeaderComponent } from './header/header.component';

import { AboutComponent } from './allUsers/about/about.component';
import { ContactComponent } from './allUsers/contact/contact.component';
import { UsersComponent } from './allUsers/users/users.component';
import { UserslistComponent } from './allUsers/userslist/userslist.component';
import { UserslistitemComponent } from './allUsers/userslistitem/userslistitem.component';
import { UserscreateComponent } from './allUsers/userscreate/userscreate.component';
import { ViewuserComponent } from './allUsers/viewuser/viewuser.component';
import { DatafilterPipe } from './appPipes/datafilter.pipe';
import { UserseditComponent } from './allUsers/usersedit/usersedit.component';



@NgModule({
  declarations: [
    AppComponent,   
    HeaderComponent,
    AboutComponent,
    ContactComponent,
    UsersComponent,
    UserslistComponent,
    UserslistitemComponent,
    UserscreateComponent,
    ViewuserComponent,
    DatafilterPipe,
    UserseditComponent,   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule  
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

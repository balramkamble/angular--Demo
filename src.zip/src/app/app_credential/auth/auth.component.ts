import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/shared/auth.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss']
})
export class AuthComponent implements OnInit {

  em: string;
  pwd: string;

  loginForm: FormGroup;

  constructor(private _authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(8)])
    })
  }

  onAddLogin() {
    this.em = this.loginForm.value.email;
    this.pwd = this.loginForm.value.password;

    console.log(this.em, this.pwd)

    let flag = this._authService.onLogin(this.em, this.pwd)
    if (flag) {
      this.router.navigate(['users'])
    }
  }
}

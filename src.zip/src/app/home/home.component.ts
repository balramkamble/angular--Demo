import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {

    const nwobservable = new Observable((observer) => {
      for (let i = 0; i <= 5; i++) {
        if (i === 4) {
          observer.error('error 4')
        }
        observer.next(i);
      }
      observer.complete();
      observer.next(1000);
    })

    let observer = {
      next: (data: number) => console.log(data),
      error: (error: string) => console.log(error),
      complete: () => console.log('completed')
    }
    nwobservable.subscribe(observer)
  }

}
